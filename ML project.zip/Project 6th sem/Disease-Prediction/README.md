# Machine-Learning-Disease-Prediction-And-Drug-Recommendation
Get the full course https://www.udemy.com/course/machine-learning-disease-prediction-and-drug-recommendation/?instructorPreviewMode=guest

Run Anacond prompt as administrator, then install the following packages using commands below

pip install django==3.3
pip install Pillow
pip install mysqlclient==1.4.2.post1
